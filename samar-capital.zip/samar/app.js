/* سمر العاصمة — game logic (vanilla JS) */
(() => {
const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];
const AR = n => String(n).replace(/\d/g, d => '٠١٢٣٤٥٦٧٨٩'[d]);
const COLORS = { blue: '#4BBFF0', coral: '#FF6B6B', purple: '#A68BFF', mint: '#3DDC97' };
const CATS = {
  '56': { label: '٥ / ٦', start: 5, groups: [['بو عبدالرحمن', 'blue'], ['بو عثمان', 'coral'], ['بو محسن', 'mint']] },
  '78': { label: '٧ / ٨', start: 3, groups: [['بو سعود', 'blue'], ['بو جاسم', 'coral'], ['بو يوسف', 'purple'], ['بو إبراهيم', 'mint']] }
};
const ROUNDS = 3, QPR = 3, QTIME = 60;
const PRIZES = [
  { k: 'free', t: 'استحواذ مجاني', d: 'استحوذوا على منطقة من مجموعة ثانية ببلاش… في هذا الهجوم بس!', c: 'coral' },
  { k: 'shield', t: 'درع حماية', d: 'يحمي كل مناطقكم… أول ما أحد يهاجم أي منطقة لكم، الهجوم ينصد ويطيح الدرع!', c: 'blue' },
  { k: 'minus', t: 'خصم نقطة', d: 'اختاروا مجموعة وننقص منها نقطة', c: 'white' },
  { k: 'plus', t: '+١ نقطة', d: 'نقطة زيادة لكم على طول!', c: 'mint' }
];
const QSET = [
  ['متى كان صلح الحديبية؟', '٦ هـ'], ['أكبر دولة عربية من حيث المساحة؟', 'الجزائر'], ['من بطل كأس العالم ٢٠٠٦؟', 'إيطاليا'],
  ['في أي قطعة يقع بيت المعالي؟', 'قطعة ٤'], ['«كلا إذا دكت الأرض دكاً دكاً» في أي سورة؟', 'سورة الفجر'], ['ما هو الاسم الذي يجمع صفات الخير والإحسان والعطاء؟', 'البَرّ'],
  ['ما هو الاسم الذي يختص الله برحمته فيه عباده المؤمنين؟', 'الرحيم'], ['ما هو الكوكب الأحمر؟', 'المريخ'], ['من الفائز بالكرة الذهبية عام ٢٠٠٧؟', 'كاكا']
];
const DEFAULT_Q = { '56': QSET, '78': QSET };
const KEY = 'samar-capital-v1', QKEY = 'samar-capital-questions-v2';

/* ---------------- icons ---------------- */
const IC = {
  check: (s = 18) => `<svg width="${s}" height="${s}" viewBox="0 0 24 24"><path d="M4 12.5l5 5L20 6.5" fill="none" stroke="#111" stroke-width="3.2" stroke-linecap="round" stroke-linejoin="round"/></svg>`,
  x: (s = 12) => `<svg width="${s}" height="${s}" viewBox="0 0 24 24"><path d="M6 6l12 12M18 6L6 18" stroke="#111" stroke-width="3.4" stroke-linecap="round"/></svg>`,
  shield: (s = 16, f = '#fff') => `<svg width="${s}" height="${s}" viewBox="0 0 24 24"><path d="M12 2l8 3v6c0 5-3.4 9.3-8 11-4.6-1.7-8-6-8-11V5z" fill="${f}" stroke="#111" stroke-width="2.2" stroke-linejoin="round"/></svg>`,
  coin: (s = 18) => `<svg class="coin" width="${s}" height="${s}" viewBox="0 0 28 28"><circle cx="14" cy="14" r="12.5" fill="#FFD23F" stroke="#111" stroke-width="2.5"/><circle cx="14" cy="14" r="8.5" fill="none" stroke="#E8A500" stroke-width="2"/><path d="M14 8.2l1.7 3.7 4 .4-3 2.7.9 4L14 17l-3.6 2 .9-4-3-2.7 4-.4z" fill="#111"/></svg>`,
  warn: (s = 20) => `<svg width="${s}" height="${s}" viewBox="0 0 24 24"><circle cx="12" cy="12" r="10" fill="#FF6B6B" stroke="#111" stroke-width="2.2"/><path d="M12 6.5v7" stroke="#111" stroke-width="2.6" stroke-linecap="round"/><circle cx="12" cy="17.3" r="1.5" fill="#111"/></svg>`,
  undo: `<svg width="20" height="20" viewBox="0 0 24 24"><path d="M9 14L4 9l5-5" fill="none" stroke="#111" stroke-width="2.8" stroke-linecap="round" stroke-linejoin="round"/><path d="M4 9h10.5a5.5 5.5 0 0 1 0 11H11" fill="none" stroke="#111" stroke-width="2.8" stroke-linecap="round" stroke-linejoin="round"/></svg>`,
  gear: `<svg width="22" height="22" viewBox="0 0 24 24"><circle cx="12" cy="12" r="3.5" fill="none" stroke="#111" stroke-width="2.6"/><path d="M12 2.5v3M12 18.5v3M2.5 12h3M18.5 12h3M5.3 5.3l2.1 2.1M16.6 16.6l2.1 2.1M5.3 18.7l2.1-2.1M16.6 7.4l2.1-2.1" stroke="#111" stroke-width="2.6" stroke-linecap="round"/></svg>`,
  home: `<svg width="22" height="22" viewBox="0 0 24 24"><path d="M3 11l9-7 9 7v9a1 1 0 0 1-1 1h-5v-6H9v6H4a1 1 0 0 1-1-1z" fill="none" stroke="#111" stroke-width="2.6" stroke-linejoin="round"/></svg>`,
  star: (s, c) => `<svg width="${s}" height="${s}" viewBox="0 0 24 24"><path d="M12 1.5l3 6.6 7.2.7-5.4 4.8 1.6 7.1L12 17.1l-6.4 3.6 1.6-7.1L1.8 8.8 9 8.1z" fill="${c}" stroke="#111" stroke-width="1.2" stroke-linejoin="round"/></svg>`,
  box: (c) => `<svg width="140" height="150" viewBox="0 0 140 150"><rect x="14" y="58" width="116" height="86" rx="10" fill="${c}" stroke="#111" stroke-width="4"/><rect x="6" y="40" width="128" height="28" rx="8" fill="${c}" stroke="#111" stroke-width="4"/><rect x="60" y="40" width="22" height="104" fill="#FFC20E" stroke="#111" stroke-width="4"/><path d="M71 40 C 50 8, 26 22, 44 38 Z M71 40 C 92 8, 116 22, 98 38 Z" fill="#FFC20E" stroke="#111" stroke-width="4" stroke-linejoin="round"/></svg>`,
  swords: (s = 150) => `<svg width="${s}" height="${s}" viewBox="0 0 24 24"><path d="M3 3l11 11M3 3h4l9 9M3 3v4l9 9" fill="#fff" stroke="#111" stroke-width="1.4" stroke-linejoin="round"/><path d="M13 16l3 3M16 13l3 3M15.5 19.5l4-4 1.5 1.5-4 4z" fill="#FFC20E" stroke="#111" stroke-width="1.4" stroke-linejoin="round"/><path d="M21 3l-8 8M21 3h-4l-5 5M21 3v4l-5 5" fill="#fff" stroke="#111" stroke-width="1.4" stroke-linejoin="round"/><path d="M8 13l-3 3M5 13l3 3M3 19.5l4-4-1.5-1.5-4 4z" fill="#FFC20E" stroke="#111" stroke-width="1.4" stroke-linejoin="round"/></svg>`,
  plus: (s = 150) => `<svg width="${s}" height="${s}" viewBox="0 0 24 24"><circle cx="12" cy="12" r="10" fill="#3DDC97" stroke="#111" stroke-width="1.4"/><path d="M12 7v10M7 12h10" stroke="#111" stroke-width="2.4" stroke-linecap="round"/></svg>`,
  minus: (s = 150) => `<svg width="${s}" height="${s}" viewBox="0 0 24 24"><circle cx="12" cy="12" r="10" fill="#FF6B6B" stroke="#111" stroke-width="1.4"/><path d="M7 12h10" stroke="#111" stroke-width="2.4" stroke-linecap="round"/></svg>`,
  bigShield: (s = 150) => `<svg width="${s}" height="${s}" viewBox="0 0 24 24"><path d="M12 2l8 3v6c0 5-3.4 9.3-8 11-4.6-1.7-8-6-8-11V5z" fill="#4BBFF0" stroke="#111" stroke-width="1.2" stroke-linejoin="round"/><path d="M8.5 12l2.4 2.4 4.8-4.8" fill="none" stroke="#111" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"/></svg>`
};
const prizeIcon = k => ({ free: IC.swords(140), shield: IC.bigShield(140), minus: IC.minus(140), plus: IC.plus(140) })[k];

/* ---------------- sound (tiny WebAudio) ---------------- */
let actx;
function beep(freqs, dur = .12, type = 'square', vol = .08) {
  try {
    actx = actx || new (window.AudioContext || window.webkitAudioContext)();
    let t = actx.currentTime;
    for (const f of [].concat(freqs)) {
      const o = actx.createOscillator(), g = actx.createGain();
      o.type = type; o.frequency.value = f; g.gain.setValueAtTime(vol, t); g.gain.exponentialRampToValueAtTime(.001, t + dur);
      o.connect(g).connect(actx.destination); o.start(t); o.stop(t + dur); t += dur * .9;
    }
  } catch (e) {}
}
const SFX = {
  click: () => beep(660, .05, 'triangle', .05),
  point: () => beep([660, 880], .09, 'triangle'),
  capture: () => beep([392, 523, 659, 784], .11, 'square', .07),
  free: () => beep([523, 784], .1, 'triangle'),
  block: () => beep([300, 200, 140], .14, 'sawtooth', .06),
  tick: () => beep(1000, .05, 'sine', .05),
  end: () => beep([880, 660, 440], .2, 'square', .08),
  open: () => beep([523, 659, 784, 1047], .12, 'triangle', .08)
};

/* ---------------- state ---------------- */
let S = load() || null;
let history = [];
let QB = loadQ();
function loadQ() { return structuredClone(DEFAULT_Q); }
function saveQ() { try { localStorage.setItem(QKEY, JSON.stringify(QB)); } catch (e) {} }
function load() { try { return JSON.parse(localStorage.getItem(KEY)); } catch (e) { return null; } }
function save() { try { if (S) localStorage.setItem(KEY, JSON.stringify(S)); } catch (e) {} }
function snap() { history.push(JSON.stringify(S)); if (history.length > 40) history.shift(); }
function undo() { if (!history.length) return toast('ما في شي نتراجع عنه'); S = JSON.parse(history.pop()); save(); stopTimer(); render(); toast('تم التراجع'); }

function newGame(cat) {
  const c = CATS[cat];
  S = {
    screen: 'rules', cat,
    groups: c.groups.map(([name, color]) => ({ name, color, points: 0, shield: false, free: 0, rc: 0 })),
    owner: Object.fromEntries(REGIONS.map(r => [r.n, null])),
    round: 1, q: 0, marks: [], timeLeft: QTIME, timerState: 'idle', revealed: false,
    breakWinner: null, box: null, turnOrder: [], turnPos: 0, sel: null, introDone: false
  };
  history = []; save();
}
function distribute() {
  const names = REGIONS.map(r => r.n).sort(() => Math.random() - .5);
  const per = CATS[S.cat].start; let i = 0;
  S.groups.forEach((g, gi) => { for (let k = 0; k < per; k++) S.owner[names[i++]] = gi; });
}
const regionCount = gi => Object.values(S.owner).filter(o => o === gi).length;
const G = gi => S.groups[gi];
const gcol = gi => COLORS[G(gi).color];

/* ---------------- stage scaling ---------------- */
const stage = $('#stage');
function fit() { const s = Math.min(innerWidth / 1440, innerHeight / 900); stage.style.transform = `scale(${s})`; }
addEventListener('resize', fit); fit();

/* ---------------- map svg ---------------- */
function mapSVG({ w = 945, interactive = false, id = 'map' } = {}) {
  const k = w / 900, h = 332 * k;
  let p = '', l = '', pills = '';
  for (const r of REGIONS) {
    const o = S.owner[r.n];
    const fill = o == null ? '#fff' : gcol(o);
    p += `<g class="rg" data-n="${r.n}"><path class="region${S.sel === r.n ? ' sel' : ''}" data-n="${r.n}" d="${r.d}" fill="${fill}"/></g>`;
    if (r.lx != null) l += `<text class="lbl" x="${r.lx}" y="${r.ly}" font-size="${r.fs}" transform="rotate(${r.rot} ${r.lx} ${r.ly})">${r.n}</text>`;
    else {
      const wpx = r.n.length * 6.2 + 12, sx = r.px + (r.tx < r.px ? -wpx / 2 : wpx / 2) * .9;
      pills += `<line x1="${sx}" y1="${r.py}" x2="${r.tx}" y2="${r.ty}" stroke="#111" stroke-width="1.6" stroke-linecap="round"/><circle cx="${r.tx}" cy="${r.ty}" r="2.6" fill="#111"/>
      <rect class="pillbg" x="${r.px - wpx / 2}" y="${r.py - 9}" width="${wpx}" height="18" rx="9"/><text class="lbl pilltxt" x="${r.px}" y="${r.py + 1}">${r.n}</text>`;
    }
  }
  return `<svg id="${id}" class="map${interactive ? ' interactive' : ''}" width="${w}" height="${h}" viewBox="0 0 900 332"><g class="regions">${p}</g><g class="pills">${pills}</g><g class="labels">${l}</g><g class="fxl"></g></svg>`;
}
function regionCenter(n) { const r = REGIONS.find(x => x.n === n); return r.lx != null ? [r.lx, r.ly] : [r.tx, r.ty]; }
function svgToStage(svg, x, y) {
  const pt = svg.createSVGPoint(); pt.x = x; pt.y = y;
  const p = pt.matrixTransform(svg.getScreenCTM());
  const sb = stage.getBoundingClientRect(), s = sb.width / 1440;
  return [(p.x - sb.left) / s, (p.y - sb.top) / s];
}

/* ---------------- common pieces ---------------- */
function topbar(phase, nextLabel, nextFn) {
  const steps = [['أسئلة', 'q'], ['لعبة بينية', 'b'], ['هجوم واستحواذ', 'a']];
  const idx = { q: 0, b: 1, a: 2 }[phase] ?? -1;
  const st = steps.map(([t], i) => `<div class="step ${i === idx ? 'active' : i < idx ? 'done' : ''}">${t}<span class="dot">${i < idx ? IC.check(16) : AR(i + 1)}</span></div>`).join('<span class="step-line"></span>');
  return `<div class="topbar">
    <div class="brand"><span class="disp">سمر العاصمة</span><span class="pill" style="font-size:15px">الصف ${CATS[S.cat].label}</span></div>
    <div class="stepper"><span class="round-chip">الجولة ${AR(S.round)} من ${AR(ROUNDS)}</span>${st}</div>
    <div class="tools">
      <button class="icon-btn" data-act="home" title="القائمة">${IC.home}</button>
      <button class="btn white sm" data-act="undo" title="تراجع عن آخر خطوة">${IC.undo} تراجع</button>
      ${nextLabel ? `<button class="btn" id="nextBtn">${nextLabel}</button>` : ''}
    </div></div>`;
}
function groupCards(turnGi = null) {
  return `<h3>المجاميع</h3>` + S.groups.map((g, gi) => `
   <div class="gcard${gi === turnGi ? ' turn' : ''}" data-gi="${gi}">
     <div class="head" style="background:${gcol(gi)}"><span class="disp">${g.name}</span>
       <span class="badges">${g.shield ? `<span class="badge">${IC.shield(13)} عندهم درع</span>` : ''}${g.free ? `<span class="badge">استحواذ مجاني</span>` : ''}${gi === turnGi ? '<span class="badge">دورهم!</span>' : ''}</span></div>
     <div class="stats">
       <div class="stat p"><div class="l">${IC.coin(14)} النقاط</div><div class="v" data-pts="${gi}">${AR(g.points)}</div>
         <div class="adj"><button data-adj="${gi}" data-d="1">+</button><button data-adj="${gi}" data-d="-1">−</button></div></div>
       <div class="stat r"><div class="l">المناطق</div><div class="v" data-reg="${gi}">${AR(regionCount(gi))}</div></div>
     </div></div>`).join('');
}
function bindCommon(root) {
  $$('[data-act="undo"]', root).forEach(b => b.onclick = undo);
  $$('[data-act="qedit"]', root).forEach(b => b.onclick = openQEditor);
  $$('[data-act="home"]', root).forEach(b => b.onclick = () => confirmBox('ترجع للقائمة؟', 'اللعبة محفوظة وتقدر تكملها بعدين.', () => { stopTimer(); S.lastScreen = S.screen; S.screen = 'home'; save(); render(); }));
  $$('[data-adj]', root).forEach(b => b.onclick = e => { e.stopPropagation(); const gi = +b.dataset.adj, d = +b.dataset.d; snap(); G(gi).points = Math.max(0, G(gi).points + d); save(); updatePoints(gi, d); });
}
function updatePoints(gi, delta) {
  const el = $(`[data-pts="${gi}"]`); if (!el) return;
  el.textContent = AR(G(gi).points); el.classList.remove('bump'); void el.offsetWidth; el.classList.add('bump');
  if (delta) floater(el, (delta > 0 ? '+' : '−') + AR(Math.abs(delta)), delta > 0 ? '#3DDC97' : '#FF6B6B');
}
function updateRegions() { S.groups.forEach((g, gi) => { const el = $(`[data-reg="${gi}"]`); if (el && el.textContent !== AR(regionCount(gi))) { el.textContent = AR(regionCount(gi)); el.classList.remove('bump'); void el.offsetWidth; el.classList.add('bump'); } }); }
function floater(el, text, color) {
  const sb = stage.getBoundingClientRect(), s = sb.width / 1440, r = el.getBoundingClientRect();
  const f = document.createElement('div'); f.className = "floater"; f.dir = "ltr"; f.textContent = text; f.style.color = color;
  f.style.left = ((r.left - sb.left) / s + 4) + 'px'; f.style.top = ((r.top - sb.top) / s - 6) + 'px';
  $('#fx').appendChild(f); setTimeout(() => f.remove(), 1300);
}
function toast(t) { const d = document.createElement('div'); d.className = 'toast'; d.textContent = t; $('#fx').appendChild(d); setTimeout(() => d.remove(), 2700); }
function banner(title, sub, bg, icon = '') {
  $$('.banner').forEach(b => b.remove());
  const d = document.createElement('div'); d.className = 'banner'; d.style.background = bg;
  d.innerHTML = `${icon}<div class="disp">${title}</div><p>${sub}</p>`; $('#fx').appendChild(d); setTimeout(() => d.remove(), 2700);
}
function burst(x, y, colors, n = 34) {
  for (let i = 0; i < n; i++) {
    const p = document.createElement('div'); p.className = 'particle';
    p.style.background = colors[i % colors.length]; p.style.left = x + 'px'; p.style.top = y + 'px';
    $('#fx').appendChild(p);
    const a = Math.random() * Math.PI * 2, d = 80 + Math.random() * 170, rot = Math.random() * 720 - 360;
    p.animate([{ transform: 'translate(0,0) rotate(0)', opacity: 1 }, { transform: `translate(${Math.cos(a) * d}px,${Math.sin(a) * d + 80}px) rotate(${rot}deg)`, opacity: 0 }],
      { duration: 900 + Math.random() * 600, easing: 'cubic-bezier(.2,.8,.4,1)', fill: 'forwards' }).onfinish = () => p.remove();
  }
}
function confettiRain(colors, n = 70) {
  for (let i = 0; i < n; i++) {
    const p = document.createElement('div'); p.className = 'confetti';
    p.style.background = colors[i % colors.length]; p.style.left = Math.random() * 1440 + 'px'; p.style.top = '-40px';
    $('#fx').appendChild(p);
    p.animate([{ transform: `translateY(0) rotate(0)` }, { transform: `translateY(1000px) rotate(${Math.random() * 900}deg) translateX(${Math.random() * 200 - 100}px)` }],
      { duration: 2500 + Math.random() * 2500, delay: Math.random() * 2000, easing: 'linear', fill: 'forwards' }).onfinish = () => p.remove();
  }
}

/* ---------------- render router ---------------- */
function render() {
  const scr = $('#screen'); $('#fx').innerHTML = '';
  if (!S || S.screen === 'home') { scr.innerHTML = homeView(); bindHome(); return; }
  const v = { rules: rulesView, board: boardView, question: questionView, break: breakView, box: boxView, winner: winnerView }[S.screen];
  scr.innerHTML = `<div class="scr">${v()}</div>`;
  bindCommon(scr);
  ({ rules: bindRules, board: bindBoard, question: bindQuestion, break: bindBreak, box: bindBox, winner: bindWinner })[S.screen]();
}
function go(screen) { S.screen = screen; save(); render(); }

/* ---------------- HOME / category ---------------- */
function homeView() {
  const cont = S && S.cat ? `<button class="btn mint" data-cont>كمل اللعبة السابقة</button>` : '';
  return `<div class="scr">
   <div class="deco float" style="left:-70px;top:-60px"><svg width="220" height="220"><circle cx="110" cy="110" r="104" fill="#4BBFF0" stroke="#111" stroke-width="4"/></svg></div>
   <div class="deco float" style="right:30px;top:40px;animation-delay:1s">${IC.star(120, '#FFC20E')}</div>
   <div class="deco float" style="left:90px;bottom:120px;animation-delay:.5s">${IC.star(70, '#FF6B6B')}</div>
   <div class="deco" style="right:-40px;bottom:-60px;transform:rotate(18deg)"><svg width="200" height="200"><rect x="4" y="4" width="192" height="192" rx="40" fill="#3DDC97" stroke="#111" stroke-width="4"/></svg></div>
   <div class="cat-wrap">
     <span class="pill pop" style="font-size:17px;box-shadow:-3px 3px 0 #111">سمر ثقافي</span>
     <div class="disp cat-title pop">سمر العاصمة</div>
     <div class="cat-sub">جاوب، العب، واستحوذ على مناطق العاصمة… واللي يملك أكثر مناطق يفوز!</div>
     <div class="disp" style="font-size:30px;margin-top:10px">اختاروا فئتكم</div>
     <div class="cat-cards stagger">
       <div class="cat-card"><div class="disp num">٥ / ٦</div><div class="lbl">الصف</div><button class="btn white" data-cat="56">اختيار</button></div>
       <div class="cat-card"><div class="disp num">٧ / ٨</div><div class="lbl">الصف</div><button class="btn" data-cat="78">اختيار</button></div>
     </div>
     ${cont}
   </div>
  </div>`;
}
function bindHome() {
  $$('[data-cat]').forEach(b => b.onclick = () => {
    const start = () => { SFX.click(); newGame(b.dataset.cat); render(); };
    if (S && S.cat && S.screen !== 'winner') confirmBox('تبدأ لعبة جديدة؟', 'اللعبة الحالية بتنمسح.', start); else start();
  });
  const c = $('[data-cont]'); if (c) c.onclick = () => { S.screen = S.lastScreen || 'board'; if (S.screen === 'home') S.screen = 'board'; render(); };
}

/* ---------------- RULES ---------------- */
function rulesView() {
  const c = CATS[S.cat];
  const ln = (t, coin, warn) => `<div class="ln${warn ? ' warn' : ''}">${coin ? IC.coin(20) : warn ? IC.warn(18) : ''}<span>${t}</span></div>`;
  return `
  <div class="rules-head"><div style="display:flex;align-items:center;gap:14px"><span class="disp">شلون نلعب؟</span><span class="pill" style="background:var(--sun);box-shadow:-3px 3px 0 #111">الصف ${c.label}</span></div>
    <button class="btn white sm" data-act="home">تغيير الفئة</button></div>
  <div class="card groups-strip pop"><div class="chips"><span style="font-size:18px">المجاميع:</span>${S.groups.map((g, i) => `<span class="chip" style="background:${gcol(i)}">${g.name}</span>`).join('')}</div>
    <span class="chip" style="background:var(--sky)">كل مجموعة تبدأ بـ ${AR(c.start)} مناطق</span></div>
  <div class="steps stagger">
    <div class="stepcard" style="background:var(--blue)"><span class="n">١</span><span class="disp">الأسئلة</span>${ln('٣ جولات، وكل جولة ٣ أسئلة')}${ln('دقيقة لكل سؤال')}${ln('كل إجابة صح = نقطة', 1)}${ln('تجاوبون الجولة كلها صح؟ +١ نقطة بونص', 1)}</div>
    <div class="stepcard" style="background:var(--purple)"><span class="n">٢</span><span class="disp">اللعبة البينية</span>${ln('بعد كل جولة في لعبة بينية')}${ln('المشرف يختار الفايز (ممكن أكثر من مجموعة) وكل فايز يفتح صندوق الحظ')}${ln('جوائز مثل: درع حماية، +١ نقطة، خصم نقطة من مجموعة، استحواذ مجاني')}${ln('الجائزة لازم تنستخدم على طول في الهجوم اللي بعدها', 0, 1)}</div>
    <div class="stepcard" style="background:var(--coral)"><span class="n">٣</span><span class="disp">الهجوم والاستحواذ</span>${ln('منطقة فاضية = نقطة', 1)}${ln('منطقة مجموعة ثانية = نقطتين', 1)}${ln('الدرع يحمي كل مناطق المجموعة: أول هجوم على أي منطقة لهم ينصد ويطيح الدرع')}</div>
    <div class="stepcard" style="background:var(--mint)"><span class="n">٤</span><span class="disp">الفوز</span>${ln('بعد الجولة الثالثة نعد المناطق')}${ln('المجموعة اللي عندها أكثر مناطق هي الفايزة!')}</div>
  </div>
  <div class="rules-foot"><span>أول ما تضغطون «يلا نبدأ!» تتوزع المناطق عشوائياً</span><button class="btn lg" id="startBtn">يلا نبدأ!</button></div>`;
}
function bindRules() {
  $('#startBtn').onclick = () => { SFX.open(); distribute(); S.introDone = false; S.screen = 'board'; S.phase = 'intro'; save(); render(); };
}

/* ---------------- BOARD (intro + attack) ---------------- */
function boardView() {
  const intro = S.phase === 'intro';
  const turnGi = intro ? null : S.turnOrder[S.turnPos];
  const allDone = !intro && S.turnPos >= S.turnOrder.length;
  const next = intro ? `ابدأ الجولة ${AR(S.round)}` : (S.round < ROUNDS ? 'إنهاء المرحلة' : 'النتيجة النهائية');
  return `${topbar(intro ? null : 'a', next)}
  <div class="body"><div class="main">
    <div class="mapcard"><div class="mh"><div class="legend"><span><i></i>فاضية</span></div><span class="disp">خريطة العاصمة</span></div>
      <div style="display:flex;justify-content:center;position:relative" id="mapwrap">${mapSVG({ w: 970, interactive: !intro })}</div><div style="height:6px"></div></div>
    <div class="actbar" id="actbar">${intro ? introBar() : allDone ? doneBar() : actBar(turnGi)}</div>
  </div><div class="side">${groupCards(allDone ? null : turnGi)}</div></div>`;
}
function introBar() {
  return `<div class="actinfo"><span class="disp">هذي مناطقكم بالبداية!</span><span class="s">كل مجموعة عندها ${AR(CATS[S.cat].start)} مناطق، تتوزعت عشوائياً. يلا نبدأ أسئلة الجولة الأولى.</span></div>
  <div class="actbtns"><button class="btn white sm" id="reshuffle">إعادة التوزيع</button></div>`;
}
function doneBar() {
  return `<div class="actinfo"><span class="disp">خلص دور الكل!</span><span class="s">${S.round < ROUNDS ? 'اضغطوا «إنهاء المرحلة» عشان نبدأ الجولة الجاية.' : 'اضغطوا «النتيجة النهائية» عشان نشوف الفايز!'}</span></div>
  <div class="actbtns"><button class="btn white sm" id="moreTurns">دور إضافي</button></div>`;
}
function actBar(gi) {
  const g = G(gi), sel = S.sel, o = sel ? S.owner[sel] : undefined;
  let info = `<span class="disp">اختاروا منطقة من الخريطة</span><span class="s">منطقة فاضية = نقطة ، منطقة مجموعة ثانية = نقطتين${g.free ? ' ، عندكم استحواذ مجاني لازم تستخدمونه الحين!' : ''}</span>`;
  let canBuy = false, canFree = false;
  if (sel) {
    if (o === gi) info = `<span class="disp">${sel} أصلاً لكم!</span><span class="s">اختاروا منطقة ثانية</span>`;
    else {
      const cost = o == null ? 1 : 2; canBuy = g.points >= cost; canFree = g.free && o != null;
      info = `<span class="disp">الهدف: ${sel}${o != null ? ` (${G(o).name})` : ' (فاضية)'}</span><span class="s">التكلفة ${o == null ? 'نقطة' : 'نقطتين'} ، رصيدكم ${AR(g.points)} ${canBuy ? `← بعد الاستحواذ ${AR(g.points - cost)}` : '— ما يكفي'}${o != null && G(o).shield ? ' ، تنبيه: عندهم درع!' : ''}</span>`;
    }
  }
  return `<div class="turnbox" style="background:${gcol(gi)}"><span class="k">الدور الحين</span><span class="disp">${g.name}</span></div>
   <div class="actinfo">${info}</div>
   <div class="actbtns"><button class="btn white sm" id="endTurn">إنهاء الدور</button>
     ${g.free ? `<button class="btn sky" id="useFree" ${canFree ? '' : 'disabled'}>استخدم الجائزة</button>` : ''}
     <button class="btn coral" id="buy" ${canBuy ? '' : 'disabled'}>استحوذ!</button></div>`;
}
function refreshBoard() {
  const ab = $('#actbar'); if (!ab) return;
  const intro = S.phase === 'intro', allDone = !intro && S.turnPos >= S.turnOrder.length, gi = S.turnOrder[S.turnPos];
  ab.innerHTML = intro ? introBar() : allDone ? doneBar() : actBar(gi);
  $('.side').innerHTML = groupCards(allDone || intro ? null : gi);
  bindCommon($('.side')); bindActBar();
  $$('#map .region').forEach(p => p.classList.toggle('sel', p.dataset.n === S.sel));
  drawCallout();
}
function drawCallout() {
  $$('.callout').forEach(c => c.remove());
  if (!S.sel || S.phase === 'intro') return;
  const svg = $('#map'), wrap = $('#mapwrap'); if (!svg) return;
  const o = S.owner[S.sel]; const [cx, cy] = regionCenter(S.sel);
  const k = svg.width.baseVal.value / 900, ox = svg.getBoundingClientRect().left - wrap.getBoundingClientRect().left;
  const s = stage.getBoundingClientRect().width / 1440;
  const d = document.createElement('div'); d.className = 'callout';
  d.innerHTML = `<div class="t">${S.sel}<span class="o" style="background:${o == null ? '#fff' : gcol(o)}">${o == null ? 'فاضية' : G(o).name}</span></div><div class="s">${o == null ? 'منطقة فاضية ، نقطة' : 'منطقة مجموعة ثانية ، نقطتين'}</div>`;
  wrap.appendChild(d);
  let x = ox / s + cx * k, y = cy * k;
  d.style.left = Math.min(Math.max(x - d.offsetWidth / 2, 0), wrap.offsetWidth - d.offsetWidth) + 'px';
  d.style.top = Math.max(y - d.offsetHeight - 26, -8) + 'px';
}
function bindBoard() {
  if (S.phase === 'intro' && !S.introDone) {
    $$('#map .rg').forEach(g => { if (S.owner[g.dataset.n] != null) { g.classList.add('regpop'); g.style.animationDelay = (Math.random() * 1.2).toFixed(2) + 's'; } });
    S.introDone = true; save();
  }
  $('#nextBtn').onclick = () => {
    SFX.click();
    if (S.phase === 'intro') { startQuestions(); return; }
    const leftover = S.turnPos < S.turnOrder.length;
    const doNext = () => { snap(); S.groups.forEach(g => g.free = 0); S.sel = null; if (S.round < ROUNDS) { S.round++; startQuestions(); } else go('winner'); };
    if (leftover) confirmBox('في مجاميع ما خلصت دورها', 'متأكد تبي تنهي مرحلة الهجوم؟ (الاستحواذ المجاني غير المستخدم ينتهي)', doNext); else doNext();
  };
  $('#map').addEventListener('click', e => {
    if (S.phase === 'intro' || S.turnPos >= S.turnOrder.length) return;
    const p = e.target.closest('.region'); if (!p) return;
    SFX.click(); S.sel = S.sel === p.dataset.n ? null : p.dataset.n; save(); refreshBoard();
  });
  bindActBar(); drawCallout();
}
function bindActBar() {
  const r = $('#reshuffle'); if (r) r.onclick = () => { Object.keys(S.owner).forEach(k => S.owner[k] = null); distribute(); S.introDone = false; save(); render(); };
  const m = $('#moreTurns'); if (m) m.onclick = () => { snap(); S.turnPos = 0; save(); refreshBoard(); };
  const et = $('#endTurn'); if (et) et.onclick = () => { SFX.click(); snap(); S.turnPos++; S.sel = null; save(); refreshBoard(); };
  const b = $('#buy'); if (b) b.onclick = () => attempt(false);
  const f = $('#useFree'); if (f) f.onclick = () => attempt(true);
  $$('.gcard').forEach(c => c.onclick = () => { if (S.phase !== 'attack') return; const gi = +c.dataset.gi; const pos = S.turnOrder.indexOf(gi); if (pos >= 0 && pos !== S.turnPos) { snap(); S.turnPos = pos; S.sel = null; save(); refreshBoard(); } });
}
function attempt(useFree) {
  const gi = S.turnOrder[S.turnPos], g = G(gi), reg = S.sel; if (!reg) return;
  const o = S.owner[reg]; if (o === gi) return;
  const cost = useFree ? 0 : (o == null ? 1 : 2);
  if (g.points < cost) return toast('ما عندكم نقاط كافية');
  snap();
  g.points -= cost; if (useFree) g.free = 0;
  if (o != null && G(o).shield) {
    G(o).shield = false; S.sel = null; save();
    animShieldBlock(reg, gi, o); setTimeout(() => { refreshBoard(); if (cost) updatePoints(gi, -cost); }, 300);
    return;
  }
  S.owner[reg] = gi; S.sel = null; save();
  animCapture(reg, gi, o);
  setTimeout(() => { refreshBoard(); if (cost) updatePoints(gi, -cost); updateRegions(); }, 650);
}

/* ---- capture animations ---- */
function animCapture(reg, gi, prev) {
  const svg = $('#map'); const grp = $(`#map .rg[data-n="${reg}"]`); const path = grp.querySelector('path');
  const [cx, cy] = regionCenter(reg); const col = gcol(gi);
  const fxl = svg.querySelector('.fxl');
  const clipId = 'clip' + Date.now();
  fxl.insertAdjacentHTML('beforeend', `<clipPath id="${clipId}"><path d="${path.getAttribute('d')}"/></clipPath><g clip-path="url(#${clipId})"><circle cx="${cx}" cy="${cy}" r="0" fill="${col}" stroke="#111" stroke-width="3"/></g>`);
  const circ = fxl.lastElementChild.querySelector('circle');
  const enemy = prev != null;
  if (enemy) { grp.classList.remove('shake'); void grp.offsetWidth; grp.classList.add('shake'); }
  const delay = enemy ? 380 : 0;
  setTimeout(() => {
    circ.animate([{ r: 0 }, { r: 140 }], { duration: 650, easing: 'cubic-bezier(.2,.8,.3,1)', fill: 'forwards' });
    setTimeout(() => { path.setAttribute('fill', col); path.style.fill = col; fxl.innerHTML = ''; grp.classList.remove('regpop'); void grp.offsetWidth; grp.classList.add('regpop'); }, 680);
    const [sx, sy] = svgToStage(svg, cx, cy);
    burst(sx, sy, [col, '#FFC20E', '#fff'], enemy ? 46 : 22);
    dropFlag(sx, sy, col);
    if (enemy) { SFX.capture(); banner('استحواذ!', `${G(gi).name} أخذوا ${reg} من ${G(prev).name}`, col, `<div style="margin-bottom:-6px">${IC.swords(90)}</div>`); }
    else { SFX.free(); toast(`${G(gi).name} أخذوا ${reg}!`); }
  }, delay);
}
function dropFlag(x, y, col) {
  const f = document.createElement('div'); f.className = 'flag';
  f.innerHTML = `<svg width="44" height="60" viewBox="0 0 44 60"><path d="M8 4v54" stroke="#111" stroke-width="4" stroke-linecap="round"/><path d="M10 6h28l-7 9 7 9H10z" fill="${col}" stroke="#111" stroke-width="3" stroke-linejoin="round"/></svg>`;
  f.style.left = (x - 8) + 'px'; f.style.top = (y - 58) + 'px'; $('#fx').appendChild(f); setTimeout(() => f.remove(), 1900);
}
function animShieldBlock(reg, gi, owner) {
  const svg = $('#map'); const [cx, cy] = regionCenter(reg); const [x, y] = svgToStage(svg, cx, cy);
  const d = document.createElement('div'); d.className = 'shieldfx'; d.style.left = (x - 60) + 'px'; d.style.top = (y - 70) + 'px';
  d.innerHTML = `<svg width="120" height="140" viewBox="0 0 24 28" style="overflow:visible">
    <g class="half l"><path d="M12 3L4 6v6c0 5 3.4 9.3 8 11z" fill="#4BBFF0" stroke="#111" stroke-width="1.3" stroke-linejoin="round"/></g>
    <g class="half r"><path d="M12 3l8 3v6c0 5-3.4 9.3-8 11z" fill="#4BBFF0" stroke="#111" stroke-width="1.3" stroke-linejoin="round"/></g></svg>`;
  $('#fx').appendChild(d); SFX.block();
  const grp = $(`#map .rg[data-n="${reg}"]`); grp.classList.add('shake');
  setTimeout(() => { const l = d.querySelector('.l'), r = d.querySelector('.r'); l.style.transform = 'translate(-8px,30px) rotate(-30deg)'; r.style.transform = 'translate(8px,30px) rotate(30deg)'; l.style.opacity = r.style.opacity = 0; }, 700);
  setTimeout(() => d.remove(), 1700);
  banner('الدرع صد الهجوم!', `${G(owner).name} طاح درعهم… و${G(gi).name} خسروا الهجمة`, '#D9F2FD', `<div>${IC.bigShield(80)}</div>`);
}

/* ---------------- QUESTIONS ---------------- */
let timerId = null;
function stopTimer() { clearInterval(timerId); timerId = null; }
function startQuestions() { S.q = 0; S.groups.forEach(g => g.rc = 0); resetQ(); S.screen = 'question'; S.phase = 'q'; save(); render(); }
function resetQ() { S.marks = S.groups.map(() => false); S.timeLeft = QTIME; S.timerState = 'idle'; S.revealed = false; }
const curQ = () => (QB[S.cat] || DEFAULT_Q[S.cat])[(S.round - 1) * QPR + S.q] || ['(ما في سؤال — عدّل الأسئلة من الإعدادات)', '—'];
function fmt(t) { return AR(Math.floor(t / 60)) + ':' + AR(String(t % 60).padStart(2, '0')); }
function questionView() {
  const [q, a] = curQ();
  const st = S.timerState, pct = S.timeLeft / QTIME * 100, low = S.timeLeft <= 10 && st === 'run';
  return `${topbar('q', S.q < QPR - 1 ? 'السؤال التالي' : 'خلصت الأسئلة')}
  <div class="body"><div class="main">
    <div class="qcard">
      <div class="qhead">
        <span class="qnum">السؤال ${AR(S.q + 1)} من ${AR(QPR)}</span>
        <span class="qdots">${[0, 1, 2].map(i => `<i class="${i < S.q ? 'done' : i === S.q ? 'cur' : ''}"></i>`).join('')}</span>
        <span class="timer ${low ? 'low' : ''} ${st === 'over' ? 'over' : ''}" id="timer">${st === 'over' ? 'خلص الوقت ' : ''}${fmt(S.timeLeft)}</span>
      </div>
      <div class="tbar ${low ? 'low' : ''}" id="tbar"><i style="width:${pct}%"></i></div>
      <div style="align-self:flex-start;font-size:14px;font-weight:500">دقيقة لكل سؤال</div>
      <div class="qtext pop" style="flex:1;display:flex;align-items:center">${q}</div>
      ${S.revealed ? `<div class="answer pop">الإجابة: <span class="disp">${a}</span></div>` : ''}
      <div style="display:flex;gap:12px">
        ${st === 'idle' ? `<button class="btn mint" id="tStart">ابدأ الوقت</button>` : st === 'run' ? `<button class="btn white" id="tStop">وقّف الوقت</button>` : ''}
        <button class="btn white" id="reveal">${S.revealed ? 'خبّ الإجابة' : 'اكشف الإجابة'}</button>
      </div>
    </div>
    <div class="award">
      <div class="row"><span class="disp" style="font-size:26px">مين جاوب صح؟</span><span class="pill" style="background:var(--mint);font-size:14px">اللي يجاوب الـ٣ صح ياخذ +١ نقطة بونص</span></div>
      <div style="font-size:15px;font-weight:500">${st === 'over' ? 'الوقت خلص — المشرف يحدد المجاميع اللي جاوبت صح' : 'بعد ما يخلص الوقت، المشرف يحدد المجاميع اللي جاوبت صح'}</div>
      <div class="tiles">${S.groups.map((g, gi) => `
        <button class="tile ${S.marks[gi] ? 'on' : ''}" data-mark="${gi}" style="${S.marks[gi] ? `background:${gcol(gi)}` : ''}">
          <div class="r1"><span class="disp">${g.name}</span><span class="cbox">${S.marks[gi] ? IC.check(18) : ''}</span></div>
          <div class="marks">الجولة: ${[0, 1, 2].map(i => i < S.q ? `<i class="${i < (g.hist || []).length && g.hist[i] ? 'y' : 'n'}">${(g.hist || [])[i] ? IC.check(11) : IC.x(9)}</i>` : `<i></i>`).join('')}</div>
        </button>`).join('')}</div>
      <div style="display:flex;gap:12px"><button class="btn" id="confirmQ">ثبّت النقاط</button></div>
    </div>
  </div><div class="side">${groupCards()}</div></div>`;
}
function bindQuestion() {
  const tick = () => {
    S.timeLeft--; if (S.timeLeft <= 10 && S.timeLeft > 0) SFX.tick();
    if (S.timeLeft <= 0) { S.timeLeft = 0; S.timerState = 'over'; stopTimer(); SFX.end(); save(); render(); return; }
    save(); const t = $('#timer'), b = $('#tbar');
    if (t) { t.textContent = fmt(S.timeLeft); t.classList.toggle('low', S.timeLeft <= 10); }
    if (b) { b.querySelector('i').style.width = (S.timeLeft / QTIME * 100) + '%'; b.classList.toggle('low', S.timeLeft <= 10); }
  };
  if (S.timerState === 'run' && !timerId) timerId = setInterval(tick, 1000);
  const ts = $('#tStart'); if (ts) ts.onclick = () => { SFX.click(); S.timerState = 'run'; save(); render(); };
  const tp = $('#tStop'); if (tp) tp.onclick = () => { stopTimer(); S.timerState = 'over'; SFX.end(); save(); render(); };
  $('#reveal').onclick = () => { S.revealed = !S.revealed; save(); render(); };
  $$('[data-mark]').forEach(b => b.onclick = () => { SFX.click(); const gi = +b.dataset.mark; S.marks[gi] = !S.marks[gi]; save(); render(); });
  const confirmFn = () => {
    stopTimer(); snap();
    S.groups.forEach((g, gi) => { g.hist = g.hist || []; g.hist[S.q] = !!S.marks[gi]; if (S.marks[gi]) { g.points++; g.rc++; } });
    const winners = S.groups.map((g, gi) => S.marks[gi] ? gi : -1).filter(x => x >= 0);
    winners.forEach(gi => updatePoints(gi, 1)); if (winners.length) SFX.point();
    if (S.q < QPR - 1) { S.q++; resetQ(); save(); setTimeout(render, winners.length ? 700 : 0); }
    else {
      const bonus = S.groups.map((g, gi) => g.rc === QPR ? gi : -1).filter(x => x >= 0);
      bonus.forEach(gi => G(gi).points++);
      S.groups.forEach(g => g.hist = []);
      S.screen = 'break'; S.breakWinners = []; S.boxQueue = []; S.box = null; save();
      setTimeout(() => { render(); if (bonus.length) { banner('بونص الجولة!', bonus.map(gi => G(gi).name).join(' و') + ' جاوبوا كل الأسئلة صح: +١ نقطة', '#3DDC97', IC.coin(70)); SFX.point(); } }, winners.length ? 700 : 0);
    }
  };
  $('#confirmQ').onclick = confirmFn;
  $('#nextBtn').onclick = confirmFn;
}

/* ---------------- BREAK ---------------- */
function breakView() {
  const ws = S.breakWinners || [];
  const names = ws.map(gi => G(gi).name).join(' و');
  return `${topbar('b', null)}
  <div class="deco" style="left:90px;top:330px;transform:rotate(-12deg)"><div class="lbox idle">${IC.box('#4BBFF0')}<span class="num">؟</span></div></div>
  <div class="deco" style="right:60px;top:600px;transform:rotate(10deg)"><div class="lbox idle">${IC.box('#4BBFF0')}<span class="num">؟</span></div></div>
  <div class="center-col">
    <span class="pill pop" style="background:var(--mint);font-size:18px;box-shadow:-3px 3px 0 #111">خلصت أسئلة الجولة ${AR(S.round)} ${IC.check(18)}</span>
    <div class="hero"><div class="disp">وقت البينية!</div><p>المشرف بيشرح لكم اللعبة الحين… جهزوا أنفسكم!</p></div>
    <div class="picker">
      <span class="disp">للمشرف: منو فاز بالبينية؟</span>
      <div style="font-size:16px;font-weight:500;margin-top:-10px">تقدر تختار أكثر من مجموعة — كل مجموعة فايزة تفتح صندوق</div>
      <div class="pick-row">${S.groups.map((g, gi) => { const on = ws.includes(gi); return `<button class="pickbtn ${on ? 'on' : ''}" data-win="${gi}" style="${on ? `background:${gcol(gi)}` : ''}"><span class="cbox">${on ? IC.check(18) : ''}</span>${g.name}${on ? '' : `<span class="sw" style="background:${gcol(gi)}"></span>`}</button>`; }).join('')}</div>
      <div class="rule">${IC.warn()} الجائزة لازم تنستخدم على طول في الهجوم والاستحواذ اللي بعد البينية</div>
      <div style="display:flex;gap:12px"><button class="btn white sm" id="noWin">بدون صندوق — روح للهجوم</button><button class="btn" id="openBox" ${ws.length ? '' : 'disabled'}>${ws.length ? `افتح صندوق الحظ لـ${names}` : 'افتح صندوق الحظ'}</button></div>
    </div>
  </div>`;
}
function bindBreak() {
  $$('[data-win]').forEach(b => b.onclick = () => {
    SFX.click(); const gi = +b.dataset.win; S.breakWinners = S.breakWinners || [];
    S.breakWinners = S.breakWinners.includes(gi) ? S.breakWinners.filter(x => x !== gi) : [...S.breakWinners, gi];
    save(); render();
  });
  $('#openBox').onclick = () => { S.boxQueue = [...S.breakWinners]; S.boxIdx = 0; S.box = newBox(); go('box'); };
  $('#noWin').onclick = () => { S.boxQueue = []; startAttack(); };
}

/* ---------------- BOX ---------------- */
const boxGi = () => S.boxQueue[S.boxIdx];
function rnd(n) { try { const a = new Uint32Array(1); crypto.getRandomValues(a); return a[0] % n; } catch (e) { return Math.floor(Math.random() * n); } }
function newBox() {
  const bag = PRIZES.flatMap(p => [p.k, p.k]); // 8 boxes, 2 of each prize
  for (let i = bag.length - 1; i > 0; i--) { const j = rnd(i + 1); [bag[i], bag[j]] = [bag[j], bag[i]]; }
  return { opened: null, prize: null, minusTarget: null, bag };
}
function boxView() {
  const gi = boxGi(), b = S.box, cols = ['#A68BFF', '#3DDC97', '#FF6B6B', '#4BBFF0', '#3DDC97', '#A68BFF', '#4BBFF0', '#FF6B6B'];
  const nextGi = S.boxQueue[S.boxIdx + 1];
  const pz = b.prize && PRIZES.find(p => p.k === b.prize);
  let card = `<div class="reveal empty"><div class="disp" style="font-size:40px">اختاروا صندوق!</div><p>الجائزة بتطلع هنا</p></div>`;
  if (pz) {
    let extra = '';
    if (pz.k === 'minus' && b.minusTarget == null) extra = `<div style="font-weight:800">من أي مجموعة؟</div><div style="display:flex;gap:8px;flex-wrap:wrap;justify-content:center">${S.groups.map((g, i) => i === gi ? '' : `<button class="pickbtn" style="font-size:20px;padding:6px 14px" data-minus="${i}"><span class="sw" style="background:${gcol(i)}"></span>${g.name}</button>`).join('')}</div>`;
    else extra = `<div class="rule" style="font-size:15px;padding:6px 12px">${IC.warn(18)} لازم ينستخدم في الهجوم الياي على طول</div>` +
      (nextGi != null ? `<button class="btn" id="nextBox">الصندوق اللي بعده: ${G(nextGi).name}</button>` : `<button class="btn mint" id="toAttack">يلا للهجوم</button>`);
    card = `<div class="reveal in"><span class="pill" style="background:var(--sun);font-size:15px">طلع لـ${G(gi).name}!</span>${prizeIcon(pz.k)}<div class="disp">${pz.t}</div><p>${pz.d}</p>${extra}</div>`;
  }
  const count = S.boxQueue.length > 1 ? `<span class="pill" style="font-size:16px">صندوق ${AR(S.boxIdx + 1)} من ${AR(S.boxQueue.length)}</span>` : '';
  return `${topbar('b', null)}
  <div class="boxbody">
    <div class="boxarea">
      <div class="ttl"><span class="disp">صندوق الحظ</span>${count}</div>
      <div class="whose" style="background:${gcol(gi)}"><span style="font-size:20px;font-weight:800">هذا الصندوق حق</span><span class="disp">${G(gi).name}</span></div>
      <div style="font-size:22px;font-weight:500">${b.opened == null ? 'اختاروا صندوق وشوفوا حظكم! كل صندوق فيه جائزة مختلفة' : 'شوفوا شنو كان في باقي الصناديق!'}</div>
      <div class="boxgrid">${cols.map((c, i) => `<button class="lbox ${b.opened == null ? 'idle' : i === b.opened ? 'picked' : 'dim'}" data-box="${i}">${IC.box(c)}<span class="num">${AR(i + 1)}</span>${b.opened != null && b.bag ? `<span class="peek">${PRIZES.find(p => p.k === b.bag[i]).t}</span>` : ''}</button>`).join('')}</div>
      <div class="prizes"><span>وش ممكن يطلع:</span><span class="chip" style="background:var(--mint)">+١ نقطة لكم</span><span class="chip" style="background:#fff">خصم نقطة من مجموعة</span><span class="chip" style="background:var(--blue)">درع حماية</span><span class="chip" style="background:var(--coral)">استحواذ مجاني على منطقة خصم</span></div>
    </div>
    ${card}
  </div>`;
}
function bindBox() {
  const gi = boxGi();
  $$('[data-box]').forEach(btn => btn.onclick = () => {
    if (S.box.opened != null) return;
    const i = +btn.dataset.box; snap();
    btn.classList.remove('idle'); btn.classList.add('opening'); SFX.click();
    $$('[data-box]').forEach(o => { if (o !== btn) o.classList.add('dim'); });
    setTimeout(() => {
      if (!S.box.bag) S.box.bag = newBox().bag;
      const pz = PRIZES.find(p => p.k === S.box.bag[i]);
      S.box.opened = i; S.box.prize = pz.k;
      if (pz.k === 'plus') G(gi).points++;
      if (pz.k === 'shield') G(gi).shield = true;
      if (pz.k === 'free') G(gi).free = 1;
      save(); SFX.open(); render();
      const r = $('.reveal').getBoundingClientRect(), sb = stage.getBoundingClientRect(), s = sb.width / 1440;
      burst((r.left - sb.left + r.width / 2) / s, (r.top - sb.top + 160) / s, [gcol(gi), '#FFC20E', '#fff'], 50);
    }, 850);
  });
  $$('[data-minus]').forEach(b => b.onclick = () => { snap(); const t = +b.dataset.minus; G(t).points = Math.max(0, G(t).points - 1); S.box.minusTarget = t; save(); render(); toast(`نقصت نقطة من ${G(t).name}`); });
  const nb = $('#nextBox'); if (nb) nb.onclick = () => { SFX.click(); S.boxIdx++; S.box = newBox(); save(); render(); };
  const ta = $('#toAttack'); if (ta) ta.onclick = startAttack;
}

/* ---------------- ATTACK start ---------------- */
function startAttack() {
  const n = S.groups.length, off = (S.round - 1) % n;
  const base = [...Array(n).keys()].map(i => (i + off) % n);
  // break-game winners go first so their prizes are used right away
  const first = S.boxQueue || [];
  S.turnOrder = [...first, ...base.filter(x => !first.includes(x))];
  S.turnPos = 0; S.sel = null; S.phase = 'attack'; go('board');
}

/* ---------------- WINNER ---------------- */
function ranking() { return S.groups.map((g, gi) => ({ gi, r: regionCount(gi), p: g.points })).sort((a, b) => b.r - a.r || b.p - a.p); }
function winnerView() {
  const rk = ranking(); const [a, b, c] = rk; const rest = rk.slice(3);
  const pod = (x, place, h, crown) => x ? `<div class="pod">${crown ? `<svg width="64" height="44" viewBox="0 0 64 44"><path d="M4 40 L8 10 L22 24 L32 4 L42 24 L56 10 L60 40 Z" fill="#fff" stroke="#111" stroke-width="4" stroke-linejoin="round"/></svg>` : ''}
     <div class="tag" style="background:${gcol(x.gi)}"><div class="disp">${G(x.gi).name}</div><div style="font-size:15px;font-weight:800">${AR(x.r)} مناطق</div></div>
     <div class="blk" style="height:${h}px;animation-delay:${place * .25}s">${AR(place)}</div></div>` : '';
  return `<div class="win"><div class="win-col">
    <div style="text-align:center"><div class="disp" style="font-size:30px">انتهى السمر!</div><div class="disp big">أبطال العاصمة</div></div>
    <div class="win-row">
      <div class="podium"><div class="pod-steps">${pod(b, 2, 170)}${pod(a, 1, 230, true)}${pod(c, 3, 120)}</div>
        ${rest.map((x, i) => `<div class="pill" style="font-size:18px;box-shadow:-4px 4px 0 #111">${AR(i + 4)} — ${G(x.gi).name} ، ${AR(x.r)} مناطق</div>`).join('')}
        <button class="btn white" id="again">سمر جديد</button></div>
      <div class="finalmap"><div class="disp" style="font-size:30px">الخريطة النهائية</div>${mapSVG({ w: 720, id: 'fmap' })}
        <div style="display:flex;gap:8px">${rk.map(x => `<span class="pill" style="background:${gcol(x.gi)};font-size:14px">${G(x.gi).name} ${AR(x.r)}</span>`).join('')}</div></div>
    </div></div></div>`;
}
function bindWinner() {
  setTimeout(() => confettiRain(Object.values(COLORS).concat('#fff', '#FFC20E')), 400);
  SFX.open();
  $('#again').onclick = () => confirmBox('نبدأ سمر جديد؟', 'النتيجة الحالية بتنمسح.', () => { try { localStorage.removeItem(KEY); } catch (e) {} S = null; history = []; render(); });
}

/* ---------------- modals ---------------- */
function confirmBox(title, sub, yes) {
  const m = $('#modal');
  m.innerHTML = `<div class="mbox confirm"><div class="disp">${title}</div><div style="font-weight:500;font-size:18px">${sub}</div><div class="mfoot" style="justify-content:center"><button class="btn white" id="mNo">لا</button><button class="btn coral" id="mYes">إي</button></div></div>`;
  m.classList.add('on');
  $('#mNo').onclick = () => m.classList.remove('on');
  $('#mYes').onclick = () => { m.classList.remove('on'); yes(); };
}
function openQEditor() {
  const m = $('#modal'); let tab = (S && S.cat) || '78';
  const draw = () => {
    m.innerHTML = `<div class="mbox"><div style="display:flex;justify-content:space-between;align-items:center"><span class="disp">أسئلة السمر</span>
      <div class="mtabs"><button class="btn sm ${tab === '56' ? '' : 'white'}" data-tab="56">الصف ٥ / ٦</button><button class="btn sm ${tab === '78' ? '' : 'white'}" data-tab="78">الصف ٧ / ٨</button></div></div>
      <div style="font-weight:500">٩ أسئلة لكل فئة: كل ٣ أسئلة جولة. التعديلات تنحفظ على هذا الجهاز.</div>
      <div class="qlist">${QB[tab].map((r, i) => `<div class="qrow"><span class="pill" style="font-size:14px;justify-content:center">ج${AR(Math.floor(i / 3) + 1)} ، س${AR(i % 3 + 1)}</span><input data-qi="${i}" data-f="0" value="${r[0].replace(/"/g, '&quot;')}" placeholder="السؤال"><input data-qi="${i}" data-f="1" value="${r[1].replace(/"/g, '&quot;')}" placeholder="الإجابة"></div>`).join('')}</div>
      <div class="mfoot"><button class="btn white sm" id="qReset">رجّع الأسئلة الافتراضية</button><div style="display:flex;gap:10px"><button class="btn white" id="qClose">إلغاء</button><button class="btn mint" id="qSave">حفظ</button></div></div></div>`;
    $$('[data-tab]', m).forEach(b => b.onclick = () => { collect(); tab = b.dataset.tab; draw(); });
    $('#qClose').onclick = () => { QB = loadQ(); m.classList.remove('on'); };
    $('#qSave').onclick = () => { collect(); saveQ(); m.classList.remove('on'); toast('انحفظت الأسئلة'); if (S && S.screen === 'question') render(); };
    $('#qReset').onclick = () => { QB[tab] = structuredClone(DEFAULT_Q[tab]); draw(); };
  };
  const collect = () => $$('[data-qi]', m).forEach(inp => { QB[tab][+inp.dataset.qi][+inp.dataset.f] = inp.value.trim(); });
  draw(); m.classList.add('on');
}

/* ---------------- boot ---------------- */
window.__samar = { get S() { return S; }, render, save };
window.addEventListener('beforeunload', () => { if (S) { if (S.screen !== 'home') S.lastScreen = S.screen; save(); } });
if (S && S.screen !== 'home') { S.lastScreen = S.screen; }
Promise.race([document.fonts.ready, new Promise(r => setTimeout(r, 1500))]).then(render);
})();
